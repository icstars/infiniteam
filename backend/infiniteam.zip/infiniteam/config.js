'use strict';

const infiniteam_heroku = {
  DATABASE_CONNECTION_URL : "postgres://soqzgikwpivlko:dl9EaraOTtz1wqKEqZpkz2x6fo@ec2-54-243-48-178.compute-1.amazonaws.com:5432/d770t3ilcmoivr?ssl=true"
};

module.exports = infiniteam_heroku;
